var pays = [
  {
    Pays: "Afghanistan",
    Capitale: "Kaboul",
  },
  {
    Pays: "Afrique du sud",
    Capitale: "Pretoria",
  },
  {
    Pays: "Albanie",
    Capitale: "Tirana",
  },
  {
    Pays: "Algérie",
    Capitale: "Alger",
  },
  {
    Pays: "Allemagne",
    Capitale: "Berlin",
  },
  {
    Pays: "Andorre",
    Capitale: "Andorre la Vieille",
  },
  {
    Pays: "Angola",
    Capitale: "Luanda",
  },
  {
    Pays: "Antigua et Barbuda",
    Capitale: "Saint John's",
  },
  {
    Pays: "Arabie Saoudite",
    Capitale: "Riyad",
  },
  {
    Pays: "Argentine",
    Capitale: "Buenos Aires",
  },
  {
    Pays: "Arménie",
    Capitale: "Erevan",
  },
  {
    Pays: "Australie",
    Capitale: "Canberra",
  },
  {
    Pays: "Autriche",
    Capitale: "Vienne",
  },
  {
    Pays: "Azerbaidjan",
    Capitale: "Bakou",
  },

  {
    Pays: "Bahamas",
    Capitale: "Nassau",
  },
  {
    Pays: "Bahrein",
    Capitale: "Manama",
  },
  {
    Pays: "Bangladesh",
    Capitale: "Dacca",
  },
  {
    Pays: "Barbade",
    Capitale: "Bridgetown",
  },
  {
    Pays: "Belgique",
    Capitale: "Bruxelles",
  },
  {
    Pays: "Belize",
    Capitale: "Belmopan",
  },
  {
    Pays: "Bénin",
    Capitale: "Porto-Novo",
  },
  {
    Pays: "Bouthan",
    Capitale: "Thimphou",
  },
  {
    Pays: "Bélarus",
    Capitale: "Minsk",
  },
  {
    Pays: "Birmanie",
    Capitale: "Naypyidaw",
  },
  {
    Pays: "Bolivie",
    Capitale: "La Paz",
  },
  {
    Pays: "Bosnie Herzegovine",
    Capitale: "Sarajevo",
  },
  {
    Pays: "Bostswana",
    Capitale: "Gaborone",
  },
  {
    Pays: "Brésil",
    Capitale: "Brasilia",
  },
  {
    Pays: "Brunei",
    Capitale: "Bandar Seri Begawan",
  },
  {
    Pays: "Bulgarie",
    Capitale: "Sofia",
  },
  {
    Pays: "Burkina Faso",
    Capitale: "Ouagadougou",
  },
  {
    Pays: "Burundi",
    Capitale: "Bujumbura",
  },

  {
    Pays: "Cambodge",
    Capitale: "Phnom Penh",
  },
  {
    Pays: "Cameroun",
    Capitale: "Yaoundé",
  },
  {
    Pays: "Canada",
    Capitale: "Ottawa",
  },
  {
    Pays: "Cap Vert",
    Capitale: "Praia",
  },
  {
    Pays: "Centrafique",
    Capitale: "Bangui",
  },
  {
    Pays: "Chili",
    Capitale: "Santiago",
  },
  {
    Pays: "Chine",
    Capitale: "Pékin",
  },
  {
    Pays: "Chypre",
    Capitale: "Nicosie",
  },
  {
    Pays: "Colombie",
    Capitale: "Bogota",
  },
  {
    Pays: "Comores",
    Capitale: "Moroni",
  },
  {
    Pays: "Républic Dém. Congo",
    Capitale: "Kinshasa",
  },
  {
    Pays: "Congo",
    Capitale: "Brazzaville",
  },
  {
    Pays: "Corée du Nord",
    Capitale: "Pyongyang",
  },
  {
    Pays: "Corée du Sud",
    Capitale: "Séoul",
  },
  {
    Pays: "Costa Rica",
    Capitale: "San Jose",
  },
  {
    Pays: "Côte d'Ivoire",
    Capitale: "Abidjan/Yamoussoukro",
  },
  {
    Pays: "Croatie",
    Capitale: "Zagreb",
  },
  {
    Pays: "Cuba",
    Capitale: "La Havane",
  },

  {
    Pays: "Danemark",
    Capitale: "Copenhague",
  },
  {
    Pays: "Djibouti",
    Capitale: "Djibouti",
  },
  {
    Pays: "Rep. Dominicaine",
    Capitale: "Saint-Domingue",
  },
  {
    Pays: "Dominique",
    Capitale: "Roseaux",
  },

  {
    Pays: "Egypte",
    Capitale: "Le Caire",
  },
  {
    Pays: "Emirats arabes unis",
    Capitale: "Abou Dhabi",
  },
  {
    Pays: "Equateur",
    Capitale: "Quito",
  },
  {
    Pays: "Erythrée",
    Capitale: "Asmara",
  },
  {
    Pays: "Espagne",
    Capitale: "Madrid",
  },
  {
    Pays: "Estonie",
    Capitale: "Talinn",
  },
  {
    Pays: "Etats-Unis",
    Capitale: "Washington",
  },
  {
    Pays: "Ethiopie",
    Capitale: "Addis Abeba",
  },

  {
    Pays: "Fidji (iles)",
    Capitale: "Suva",
  },
  {
    Pays: "Finlande",
    Capitale: "Helsinki",
  },
  {
    Pays: "France",
    Capitale: "Paris",
  },

  {
    Pays: "Gabon",
    Capitale: "Libreville",
  },
  {
    Pays: "Gambie",
    Capitale: "Banjul",
  },
  {
    Pays: "Géorgie",
    Capitale: "Tblissi",
  },
  {
    Pays: "Ghana",
    Capitale: "Accra",
  },
  {
    Pays: "Grèce",
    Capitale: "Athènes",
  },
  {
    Pays: "Grenade",
    Capitale: "Saint-George",
  },
  {
    Pays: "Guatemala",
    Capitale: "Guatemala",
  },
  {
    Pays: "Guinée",
    Capitale: "Conakry",
  },
  {
    Pays: "Guinée Bissau",
    Capitale: "Bissau",
  },
  {
    Pays: "Guinée Equatoriale",
    Capitale: "Malabo",
  },
  {
    Pays: "Guyane",
    Capitale: "Georgetown",
  },

  {
    Pays: "Haiti",
    Capitale: "Port au prince",
  },
  {
    Pays: "Honduras",
    Capitale: "Tegucigalpa",
  },
  {
    Pays: "Hongrie",
    Capitale: "Budapest",
  },

  {
    Pays: "Inde",
    Capitale: "New Delhi",
  },
  {
    Pays: "Indonésie",
    Capitale: "Jakarta",
  },
  {
    Pays: "Irak",
    Capitale: "Bagdad",
  },
  {
    Pays: "Iran",
    Capitale: "Téhéran",
  },
  {
    Pays: "Irlande",
    Capitale: "Dublin",
  },
  {
    Pays: "Islande",
    Capitale: "Reykjavik",
  },
  {
    Pays: "Israël",
    Capitale: "Jerusalem/Tel Aviv",
  },
  {
    Pays: "Italie",
    Capitale: "Rome",
  },

  {
    Pays: "Jamaique",
    Capitale: "Kingston",
  },
  {
    Pays: "Japon",
    Capitale: "Tokyo",
  },
  {
    Pays: "Jordanie",
    Capitale: "Amman",
  },

  {
    Pays: "Kazakhstan",
    Capitale: "Astana",
  },
  {
    Pays: "Kenya",
    Capitale: "Nairobi",
  },
  {
    Pays: "Kirghizstan",
    Capitale: "Bishkek",
  },
  {
    Pays: "Kiribati",
    Capitale: "Tarawa-sud",
  },
  {
    Pays: "Koweit",
    Capitale: "Koweit",
  },

  {
    Pays: "Laos",
    Capitale: "Vientiane",
  },
  {
    Pays: "Lesotho",
    Capitale: "Maseru",
  },
  {
    Pays: "Lettonie",
    Capitale: "Riga",
  },
  {
    Pays: "Liban",
    Capitale: "Beyrouth",
  },
  {
    Pays: "Libéria",
    Capitale: "Monrovia",
  },
  {
    Pays: "Libye",
    Capitale: "Tripoli",
  },
  {
    Pays: "Liechtenstein",
    Capitale: "Vaduz",
  },
  {
    Pays: "Lituanie",
    Capitale: "Vilnius",
  },
  {
    Pays: "Luxembourg",
    Capitale: "Luxembourg",
  },

  {
    Pays: "Macédoine",
    Capitale: "Skopje",
  },
  {
    Pays: "Madagascar",
    Capitale: "Antananarivo",
  },
  {
    Pays: "Malaisie",
    Capitale: "Kuala Lumpur",
  },
  {
    Pays: "Malawi",
    Capitale: "Lilongwe",
  },
  {
    Pays: "Maldives",
    Capitale: "Malé",
  },
  {
    Pays: "Mali",
    Capitale: "Bamako",
  },
  {
    Pays: "Malte",
    Capitale: "La Valette",
  },
  {
    Pays: "Maroc",
    Capitale: "Rabat",
  },
  {
    Pays: "Marshall",
    Capitale: "Dalap Uliga Darrit",
  },
  {
    Pays: "Maurice ",
    Capitale: "Port-Louis",
  },
  {
    Pays: "Mauritanie",
    Capitale: "Nouakchott",
  },
  {
    Pays: "Mexique",
    Capitale: "Mexico",
  },
  {
    Pays: "Micronésie",
    Capitale: "Palikir",
  },
  {
    Pays: "Moldavie",
    Capitale: "Chisinau",
  },
  {
    Pays: "Monaco",
    Capitale: "Monaco",
  },
  {
    Pays: "Mongolie",
    Capitale: "Oulan Bator",
  },
  {
    Pays: "Monténégro",
    Capitale: "Podgorica",
  },
  {
    Pays: "Mozambique",
    Capitale: "Maputo",
  },

  {
    Pays: "Namibie",
    Capitale: "Windhoek",
  },
  {
    Pays: "Nauru",
    Capitale: "Yaren",
  },
  {
    Pays: "Népal",
    Capitale: "Kathmandou",
  },
  {
    Pays: "Nicaragua",
    Capitale: "Managua",
  },
  {
    Pays: "Niger",
    Capitale: "Niamey",
  },
  {
    Pays: "Nigeria",
    Capitale: "Abuja",
  },
  {
    Pays: "Norvège",
    Capitale: "Oslo",
  },
  {
    Pays: "Nouvelle-Zélande",
    Capitale: "Wellington",
  },

  {
    Pays: "Oman",
    Capitale: "Mascate",
  },
  {
    Pays: "Ouganda",
    Capitale: "Kampala",
  },
  {
    Pays: "Ouzbékistan",
    Capitale: "Tashkent",
  },

  {
    Pays: "Pakistan",
    Capitale: "Islamabad",
  },
  {
    Pays: "Palaos",
    Capitale: "Melekeok",
  },
  {
    Pays: "Palestine",
    Capitale: "Ramallah",
  },
  {
    Pays: "Panama ",
    Capitale: "Panama",
  },
  {
    Pays: "Papouasie, N. Guinée",
    Capitale: "Port Moresby",
  },
  {
    Pays: "Paraguay",
    Capitale: "Asuncion",
  },
  {
    Pays: "Pays-Bas",
    Capitale: "Amsterdam",
  },
  {
    Pays: "Pérou",
    Capitale: "Lima",
  },
  {
    Pays: "Philippines ",
    Capitale: "Manille",
  },
  {
    Pays: "Pologne",
    Capitale: "Varsovie",
  },
  {
    Pays: "Portugal",
    Capitale: "Lisbonne",
  },

  {
    Pays: "Qatar",
    Capitale: "Doha",
  },

  {
    Pays: "Roumanie",
    Capitale: "Buccarest",
  },
  {
    Pays: "Royaume-Uni",
    Capitale: "Londres",
  },
  {
    Pays: "Russie",
    Capitale: "Moscou",
  },
  {
    Pays: "Rwanda",
    Capitale: "Kigali",
  },
  {
    Pays: "St Christophe & Nieves",
    Capitale: "Basseterre",
  },
  {
    Pays: "Sainte Lucie",
    Capitale: "Castries",
  },
  {
    Pays: "Saint Marin",
    Capitale: "Saint Marin",
  },
  {
    Pays: "St Vincent & Grenadines",
    Capitale: "Kingstown",
  },
  {
    Pays: "Salomon (iles)",
    Capitale: "Honiara",
  },
  {
    Pays: "Salvador",
    Capitale: "San Salvador",
  },
  {
    Pays: "Samoa (iles)",
    Capitale: "Apia",
  },
  {
    Pays: "Sao Tome & Principe",
    Capitale: "Sao Tome",
  },
  {
    Pays: "Sénégal",
    Capitale: "Dakar",
  },
  {
    Pays: "Serbie",
    Capitale: "Belgrade",
  },
  {
    Pays: "Seychelles",
    Capitale: "Victoria",
  },
  {
    Pays: "Sierra Léone",
    Capitale: "Freetown",
  },
  {
    Pays: "Singapour",
    Capitale: "Singapour",
  },
  {
    Pays: "Slovaquie",
    Capitale: "Bratislava",
  },
  {
    Pays: "Slovénie",
    Capitale: "Ljubljana",
  },
  {
    Pays: "Somalie",
    Capitale: "Mogadiscio",
  },
  {
    Pays: "Soudan",
    Capitale: "Khartoum",
  },
  {
    Pays: "Soudan Sud",
    Capitale: "Juba",
  },
  {
    Pays: "Sri Lanka",
    Capitale: "Colombo",
  },
  {
    Pays: "Suède",
    Capitale: "Stockholm",
  },
  {
    Pays: "Suisse",
    Capitale: "Genève",
  },
  {
    Pays: "Suriname",
    Capitale: "Paramaribo",
  },
  {
    Pays: "Swaziland",
    Capitale: "Mbabane",
  },
  {
    Pays: "Syrie",
    Capitale: "Damas",
  },

  {
    Pays: "Tadjikistan",
    Capitale: "Duchanbé",
  },
  {
    Pays: "Tanzanie",
    Capitale: "Dodoma",
  },
  {
    Pays: "Tchad",
    Capitale: "Ndjamena",
  },
  {
    Pays: "Tchèque (république)",
    Capitale: "Prague",
  },
  {
    Pays: "Thailande",
    Capitale: "Bangkok",
  },
  {
    Pays: "Timor Oriental",
    Capitale: "Dili",
  },
  {
    Pays: "Togo",
    Capitale: "Lome",
  },
  {
    Pays: "Tonga",
    Capitale: "Nuku Alofa",
  },
  {
    Pays: "Trinité et Tobago",
    Capitale: "Port d'Espagne",
  },
  {
    Pays: "Tunisie",
    Capitale: "Tunis",
  },
  {
    Pays: "Turkmenistan",
    Capitale: "Ashgabat",
  },
  {
    Pays: "Turquie",
    Capitale: "Ankara",
  },
  {
    Pays: "Tuvalu (iles)",
    Capitale: "Funafuti",
  },

  {
    Pays: "Ukraine",
    Capitale: "Kiev",
  },
  {
    Pays: "Uruguay",
    Capitale: "Montevideo",
  },

  {
    Pays: "Vanuatu",
    Capitale: "Port-Vila",
  },
  {
    Pays: "Vatican",
    Capitale: "Vatican",
  },
  {
    Pays: "Venezuela",
    Capitale: "Caracas",
  },
  {
    Pays: "Vietnam",
    Capitale: "Hanoi",
  },
  {
    Pays: "Yemen",
    Capitale: "Sanaa",
  },
  {
    Pays: "Zambie",
    Capitale: "Lusaka",
  },
  {
    Pays: "Zimbabwe",
    Capitale: "Harare",
  },
];
//const pays= require('./paysxcapitales.json');

var random = [];

var min = 0;
var max = pays.length;

while (random.length < 5) {
  var n = Math.floor(Math.random() * (max - min) + min);
  if (!random.includes(n)) {
    random.push(n);
  }
}

let i = 0;
let j = 0;

var minute = 0;
var seconde = 0;
var sec;

nomPays.innerHTML = pays[random[i]].Pays;

function commencer() {
  jeu.style.display = "flex";
  debut.style.display = "none";
  sec = setInterval(exploser, 1000);
}

function pauseCache() {
  jeu.style.display = "none";
  debut.style.display = "flex";
  btnCommencer.innerHTML = "Reprendre";
  clearInterval(sec);
}

function rejouer() {
  location.reload();
}

function getCapitale() {
  let capitale = rep.value;
  if (capitale == pays[random[i]].Capitale) {
    result.innerHTML = "Bravo !";
    result.style.color = "green";
    content.style.display = "flex";
    angry.style.display = "none";
    j++;
  } else {
    result.innerHTML = "Loupé... Il s'agissait de " + pays[random[i]].Capitale;
    result.style.color = "red";
    angry.style.display = "flex";
    content.style.display = "none";
  }
  score.innerHTML = j;
  rep.value = "";
  i++;

  if (i < random.length) {
    nomPays.innerHTML = pays[random[i]].Pays;
  } else {
    clearInterval(sec);
    fin.style.display = "flex";
    btnVal.style.display = "none";
    btnPause.style.display = "none";

    setTimeout(function () {
      result.style.display = "none";
      angry.style.display = "none";
      content.style.display = "none";
    }, 3000);
    if (j < 4) {
      //nul.style.display = "flex";
      phraseResult.innerHTML =
        'ET VOUS ETES NUUUUUUUUL <img id="gifNul" src="img/suck.gif" />';
      ouh.play();
    } else {
      phraseResult.innerHTML =
        'GG BGGGGGGGGG <img id="gifBon" src="img/leo.gif" />';
      clap.play();
    }
    pScore.style.fontSize = "45px";
    pScore.style.fontSize = "red";
  }
}

function exploser() {
  seconde++;
  if (seconde == 60) {
    seconde = 0;
    minute++;
  }
  let minAffiche = minute < 10 ? "0" + minute : minute;
  let secondeAffiche = seconde < 10 ? "0" + seconde : seconde;
  horloge.innerHTML = minAffiche + ":" + secondeAffiche;
}

rep.onkeyup = function (event) {
  if (event.keyCode == 13) {
    getCapitale();
  }
};
